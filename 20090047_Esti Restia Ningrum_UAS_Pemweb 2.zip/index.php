<?php 

//membuat metode redirect dengan kode 301

header("location: frontend/index.html", true, 301);

exit();