<?php
$conn_str = "host=balarama.db.elephantsql.com " .
    "port=5432 " .
    "user=yaphkjaw " .
    "dbname=yaphkjaw " .
    "password=mf-BcoLyONN3UeTJWAA-WnjzTbI__ZJF";
$conn = pg_connect($conn_str);

// if($conn) {
//     echo "<h3>Koneksi Berhasil</h3>";
// } else {
//     echo "<h3>Koneksi GAGAL TERSAMBUNG</h3>";
// }
?>